using System.ComponentModel.DataAnnotations;


namespace IdentityDemo.Models
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "El correo electr�nico es obligatorio.")]
        [EmailAddress(ErrorMessage = "El formato del correo electr�nico no es v�lido.")]
        public string Email { get; set; }


        [Required(ErrorMessage = "La contrase�a es obligatoria.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }


        [Required(ErrorMessage = "Debes confirmar la contrase�a.")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Las contrase�as no coinciden.")]
        public string ConfirmPassword { get; set; }


        [Required(ErrorMessage = "El tel�fono es obligatorio.")]
        [Phone(ErrorMessage = "El formato del tel�fono no es v�lido.")]
        public string PhoneNumber { get; set; }
    }
}
