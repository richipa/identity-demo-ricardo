using System.ComponentModel.DataAnnotations;

namespace IdentityDemo.Models
{
    public class EditProfileViewModel
    {
        [Required(ErrorMessage = "El correo es obligatorio")]
        [EmailAddress(ErrorMessage = "El formato del correo no es v�lido")]
        public string Email { get; set; }

        [Required(ErrorMessage = "El tel�fono es obligatorio")]
        [Phone(ErrorMessage = "El formato del tel�fono no es v�lido")]
        public string PhoneNumber { get; set; }
    }
}
